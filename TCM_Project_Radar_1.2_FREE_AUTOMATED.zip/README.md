# TCM Food Project Radar 1.2 — FREE AUTOMATED STARTER

## Doel
Dagelijkse, gratis starter voor een projectradar gericht op de levensmiddelenindustrie en coating/applicatiewerk.

## Architectuur
- `index.html` — dashboard
- `data/radar.json` — projectdatabase
- `scripts/update_radar.py` — update/collector
- `.github/workflows/daily-radar.yml` — dagelijkse GitHub Action

## Gratis uitvoering
De workflow is ontworpen voor een openbaar GitHub-repository. GitHub Actions is voor publieke repositories gratis; GitHub Pages kan een publieke repository gratis publiceren. Zie de officiële GitHub-documentatie.

## Belangrijke beperking
Deze starter gebruikt bewust geen betaalde API's en geen onbeperkte scraping. Voor betrouwbare automatische projectdetectie moeten per bron RSS/API of toegestane webpagina's worden toegevoegd. De collector is daarom eerst conservatief: hij ververst de dataset en is klaar om bronconnectors toe te voegen.

## Zelflerend
Feedback kan later als expliciete velden worden toegevoegd:
- relevant / niet relevant
- score correct / te hoog / te laag
- gewonnen / verloren
- coatingwaarde werkelijk
Daarmee kunnen de scoregewichten gecontroleerd worden aangepast.

## Installatie
1. Maak een openbaar GitHub-repository, bijvoorbeeld `tcm-project-radar`.
2. Upload alle bestanden uit deze map.
3. Zet GitHub Pages aan via Settings > Pages.
4. Kies GitHub Actions als publishing source of publiceer de root/static files.
5. De workflow draait dagelijks om 05:30 UTC en kan ook handmatig worden gestart.

## Veiligheid
De workflow bevat geen betaalde secrets, tokens of creditcardgegevens.
