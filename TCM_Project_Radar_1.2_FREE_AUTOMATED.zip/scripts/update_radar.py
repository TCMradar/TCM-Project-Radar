import json, re, urllib.request
from datetime import datetime, timezone
from pathlib import Path

DATA = Path("data/radar.json")

# FREE starter collector:
# - Uses public RSS/XML feeds where available.
# - Does not require paid APIs or API keys.
# - Keeps existing curated projects.
# - Adds only high-confidence candidate signals.
#
# This intentionally does NOT scrape arbitrary sites aggressively:
# robots.txt, terms, rate limits and source stability must be respected.

FEEDS = [
    # Public RSS feeds can be added here as the project is expanded.
    # Example:
    # ("Food+Industry", "https://example.com/rss"),
]

POSITIVE = [
    "food", "voeding", "voedingsmiddelen", "zuivel", "dairy", "fabriek",
    "productielijn", "productielocatie", "uitbreiding", "modernisering",
    "nieuwbouw", "renovatie", "warehouse", "distributiecentrum",
    "foodgrade", "vloer", "coating", "beton", "productiehal"
]
NEGATIVE = ["woningbouw", "woningen", "kantoor", "retail", "school"]

def score_text(text):
    t = text.lower()
    pos = sum(1 for x in POSITIVE if x in t)
    neg = sum(1 for x in NEGATIVE if x in t)
    return max(0, min(100, 45 + pos*4 - neg*8))

def main():
    data = json.loads(DATA.read_text(encoding="utf-8"))
    data["updated_utc"] = datetime.now(timezone.utc).isoformat()
    data.setdefault("learning", {})
    data["learning"]["last_run"] = data["updated_utc"]
    data["learning"]["collector"] = "Free public-source starter; curated feeds can be added without changing dashboard."
    # Preserve curated projects. Candidate ingestion is deliberately conservative.
    DATA.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

if __name__ == "__main__":
    main()
